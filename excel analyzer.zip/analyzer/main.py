from fastapi import FastAPI, File, UploadFile, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from openpyxl import load_workbook, Workbook
import io
import hashlib
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Google Drive config
DRIVE_FOLDER_ID = "153ZzvonUCdqSkxOF-3SP-_yAvspVik7m"
SERVICE_ACCOUNT_FILE = "service_account.json"

creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE,
    scopes=["https://www.googleapis.com/auth/drive"]
)
drive_service = build("drive", "v3", credentials=creds)

# Database simulation
DATABASE = {}

class FileAnalysisResult(BaseModel):
    num_sheets: int
    num_rows: int
    num_cols: int
    num_tables: int
    drive_link: str

@app.post("/upload", response_model=FileAnalysisResult)
async def upload_file(file: UploadFile = File(...)):
    try:
        contents = await file.read()
        file_hash = hashlib.md5(contents).hexdigest()
        if file_hash in DATABASE:
            raise HTTPException(status_code=400, detail="File already processed.")

        workbook = load_workbook(io.BytesIO(contents))
        num_sheets = len(workbook.sheetnames)
        num_rows = num_cols = num_tables = 0

        for sheet in workbook:
            rows = list(sheet.iter_rows(values_only=True))
            if not rows:
                continue

            num_rows += len(rows)
            num_cols += max((len(row) for row in rows if row), default=0)

            # Detect tables in the sheet
            current_table = []
            for row in rows:
                if any(row):  # Check if the row is not empty
                    current_table.append(row)
                else:
                    if len(current_table) > 1:  # A table must have more than one row
                        num_tables += 1
                        save_table_to_drive(sheet.title, current_table)
                    current_table = []

            # Save any remaining table
            if len(current_table) > 1:
                num_tables += 1
                save_table_to_drive(sheet.title, current_table)

        DATABASE[file_hash] = True

        return FileAnalysisResult(
            num_sheets=num_sheets,
            num_rows=num_rows,
            num_cols=num_cols,
            num_tables=num_tables,
            drive_link=f"https://drive.google.com/drive/folders/{DRIVE_FOLDER_ID}"
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

def save_table_to_drive(sheet_title, table_data):
    """Save a detected table to Google Drive."""
    try:
        new_wb = Workbook()
        
        # Ensure a valid worksheet is created
        if not new_wb.worksheets:
            new_ws = new_wb.create_sheet("Sheet1")  # Explicitly create a new sheet
        else:
            new_ws = new_wb.active  # Get the active sheet

        # Add rows to the worksheet
        for row in table_data:
            new_ws.append(row) # type: ignore

        # Save the workbook to a BytesIO object
        bytes_io = io.BytesIO()
        new_wb.save(bytes_io)
        bytes_io.seek(0)

        # Upload the file to Google Drive
        file_metadata = {
            "name": f"{sheet_title}_table.xlsx",
            "parents": [DRIVE_FOLDER_ID],
        }
        media = MediaIoBaseUpload(bytes_io, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        drive_service.files().create(body=file_metadata, media_body=media, fields="id").execute()

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to save table to Drive: {e}")